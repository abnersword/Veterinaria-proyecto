/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.veterinaria.proyecto.Clases;
import com.mycompany.veterinaria.proyecto.DAO.ProductoServicioDAO;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author rivch
 */
public class Producto_Servicio {
    private int idProducto;
    private String nombre;
    private String tipo;
    private double precio;
    private String descripcion;
    private int stock;
    private int id_categoria;
    public Producto_Servicio(int idProducto, String nombre,
            String tipo, double precio, String descripcion, int stock) {

        this.idProducto = idProducto;
        this.nombre = nombre;
        this.tipo = tipo;
        this.precio = precio;
        this.descripcion = descripcion;
        this.stock = stock;
    }
    public void actualizarPrecio(double nuevoPrecio) {
        if (nuevoPrecio >= 0) {
            this.precio = nuevoPrecio;
        }
    }
    public void aumentarStock(int cantidad) {
        if (cantidad > 0) {
            this.stock += cantidad;
        }
    }
    public void disminuirStock(int cantidad) {
        if (cantidad > 0 && cantidad <= stock) {
            this.stock -= cantidad;
        }
    }
    public boolean disponibilidad() {
        return stock > 0;
    }
    public double calcularSubTotal(int cantidad) {
        if (cantidad < 0) {
            throw new IllegalArgumentException(
                    "La cantidad no puede ser negativa.");
        }
        return precio * cantidad;
    }
    public void registrarProducto() throws SQLException {
    new ProductoServicioDAO().guardar(this);
}

public void modificarProducto() throws SQLException {
    new ProductoServicioDAO().actualizar(this);
}

public void eliminarProducto() throws SQLException {
    new ProductoServicioDAO().eliminar(this.idProducto);
}

public static Producto_Servicio buscarProducto(int id)
        throws SQLException {

    return new ProductoServicioDAO().buscarPorId(id);
}

public static List<Producto_Servicio> listarProductos()
        throws SQLException {

    return new ProductoServicioDAO().listar();
}
    // Getters y setters
    public int getIdProducto() {
        return idProducto;
    }
    public String getNombre() {
        return nombre;
    }
    public String getTipo() {
        return tipo;
    }
    public double getPrecio() {
        return precio;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public int getStock() {
        return stock;
    }
    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }
}
